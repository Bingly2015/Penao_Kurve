package Hilbert_Peano_Kurve_JFX;


public class Hilbert_kurve  {
    private Turtle turtle;
   
    public Hilbert_kurve(int level) {
    	 turtle = new Turtle(0.5, 0.5, 0.0);
         double max = Math.pow(2, level);
         turtle.setXscale(0, max);
         turtle.setYscale(0, max);
           Hilbert(1,0,level);
                              }   
  public void step(int angle){
         double x = turtle.getX();
         double y=  turtle.getY();
    	 double oldx = turtle.getX();
         double oldy = turtle.getY();
         x += 1.0 * Math.cos(Math.toRadians(angle));
         y += 1.0 * Math.sin(Math.toRadians(angle));
          
         Kurve_Controler.gc.moveTo(turtle.scaleX(oldx), turtle.scaleY(oldy));
 	     Kurve_Controler.gc.lineTo(turtle.scaleX(x), turtle.scaleY(y));
 	    Kurve_Controler.gc.stroke();
         
		 turtle.setX(x);
		 turtle.setY(y);
		 }   
   
    
    /**orient...enterder +1 oder -1 Drehrichtung
	 * angle... 0,90,180,270,(Grad)
	 * level  rekursiv berechnen
	 */
	 public int Hilbert(int orient,int angle,int level){
		if(level--==0) return angle;
		
		angle+=orient*90;
		angle=Hilbert(-orient,angle,level);
		step(angle);
		
		angle-=orient*90;
		angle=Hilbert(orient,angle,level);
		step(angle);
		
		angle=Hilbert(orient,angle,level);
		angle-=orient*90;
		step(angle);
		
		angle=Hilbert(-orient,angle,level);
		angle+=orient*90;
		
		return angle;
		
}
	 

	 
    
    



}
