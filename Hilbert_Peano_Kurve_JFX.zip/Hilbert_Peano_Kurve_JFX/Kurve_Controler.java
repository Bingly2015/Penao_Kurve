package Hilbert_Peano_Kurve_JFX;

import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;

public class Kurve_Controler {
@FXML
        private TextField  Htief,Ptief;
@FXML
        private AnchorPane anchorPane;
@FXML
        private  Canvas   canvas;
       
	    public static GraphicsContext gc;
	    
	/**
	 *   
	 * @param e  das ist eine Art von ActionEvent
	 */
	    
   public void HilbertkurveZeichnen(ActionEvent e ){
	   	      int tiefH=0;
	  try{  
		  String s2=Htief.getText();
				  for(int i=0;i<s2.length();i++){
	    		if ( !(48<s2.charAt(i) &&s2.charAt(i)<57)){
	    			System.out.println("eingabe nicht richtig ,bitte Nummer in Text Aree  eingeben");
	    			Htief.setText("Zahl eingeben");
	    			return;
	    		}
	    	 }
		 
		tiefH= Integer.parseInt(Htief.getText());
		clean();
	    new Hilbert_kurve(tiefH);
	     
		 }catch (NullPointerException e2){
	
	}
    }
   /**
    * 
    */
   public  void clean() {
	   anchorPane.getChildren().clear();
	   canvas = new Canvas(500, 500);
	   anchorPane.getChildren().add(canvas);
		gc = canvas.getGraphicsContext2D();
   }
   
  public void PeanokurveZeichnen(ActionEvent e){
	   int tiefP=0;
		  
		try{   
			String s2=Ptief.getText();
			  for(int i=0;i<s2.length();i++){
		    		if ( !(48<s2.charAt(i) &&s2.charAt(i)<57)){
		    			System.out.println("eingabe nicht richtig ,bitte Nummer in Text Aree  eingeben");
		    			Ptief.setText("Zahl eingeben");
		    			return;
		    		}
		    	 }
			  tiefP= Integer.parseInt(Ptief.getText());
			  clean();
		     new Peano_Kurve(tiefP);
		    
		  }catch (NullPointerException e2){
		
		   }
	   
   }

}
