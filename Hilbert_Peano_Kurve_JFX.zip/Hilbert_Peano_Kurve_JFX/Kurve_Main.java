package Hilbert_Peano_Kurve_JFX;
/**
 * author Bing
 */

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.stage.Stage;

public class Kurve_Main extends Application{
	
	 public static void main(String[] arg) {
	    	launch(arg);
	    }

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		
	Parent root=FXMLLoader.load(getClass().getResource("Hilbert_Peano_Kurve.fxml"));
		Scene scene =new Scene(root);
		
		 primaryStage.setTitle("Peano_Hilbert_Kurve");
		 primaryStage.setScene(scene);
		 primaryStage.show();
		 }
}
	