package Hilbert_Peano_Kurve_JFX;



public class Turtle {
    private static double x, y;     // turtle is at (x, y)
    private double angle;    // facing this many degrees counterclockwise from the x-axis
    
   private int width  = 450;
    private  int height = 450;

 // boundary of drawing canvas, 5% border
    private  final double BORDER = 0.05;
   
    private  double xmin, ymin, xmax, ymax;
    
    // start at (x0, y0), facing a0 degrees counterclockwise from the x-axis
    public Turtle(double x0, double y0, double a0) {
        x = x0;
        y = y0;
        angle = a0;
    }
    
    public   static void clear(){
    	
    }

   
    public  double getX(){
    	return  x;
    }
    public  void setX(double xv){
    	x=xv;
    }
    public void setY(double yv){
     	y=yv;
    }
   
    public   double getY(){
    	return y;
    }


    /**
     * Set the x-scale (a 10% border is added to the values)
     * @param min the minimum value of the x-scale
     * @param max the maximum value of the x-scale
     */
    public  void setXscale(double min, double max) {
        double size = max - min;
        xmin = min - BORDER * size;
        xmax = max + BORDER * size;
    }

    /**
     * Set the y-scale (a 10% border is added to the values).
     * @param min the minimum value of the y-scale
     * @param max the maximum value of the y-scale
     */
    public  void setYscale(double min, double max) {
        double size = max - min;
        ymin = min - BORDER * size;
        ymax = max + BORDER * size;
    }

    /**
     * Set the x-scale and y-scale (a 10% border is added to the values)
     * @param min the minimum value of the x- and y-scales
     * @param max the maximum value of the x- and y-scales
     */
    public  void setScale(double min, double max) {
        setXscale(min, max);
        setYscale(min, max);
    }

    // helper functions that scale from user coordinates to screen coordinates and back
   double  scaleX(double x) { return width  * (x - xmin) / (xmax - xmin); }
   double  scaleY(double y) { return height * (ymax - y) / (ymax - ymin); }

}